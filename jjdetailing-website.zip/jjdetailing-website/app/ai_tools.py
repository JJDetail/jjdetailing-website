from transformers import pipeline
sentiment = pipeline('sentiment-analysis')
summarizer = pipeline('summarization')
# ...rest of your ai_tools.py here
